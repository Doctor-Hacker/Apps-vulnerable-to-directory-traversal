--------------------------------------------------------------------------------
                CyBroHttpServer (c) 2013-2018 Cybrotech Ltd.
--------------------------------------------------------------------------------

CyBroHttpServer is comunication interface for reading/writing CyBro variables
by name. Request is HTTP GET method, result is body in XML format.

  HTTP client <--> CyBroHttpServer <--> CyBro

Client may be CyBroMiniScada (Android or iOS), web browser, or user application.
Server is working in local network only, Internet, direct and serial connection
are not supported. Operation is automatic, no installation is needed.

CyBroHttpServer is tray application - when closed, it will run in background.
To close, right-click tray icon, and select Exit. To start server automatically,
move program to Windows startup directory.

Request example:

  http://localhost/scgi/?c6512.rtc_min&c6512.rtc_sec

Response is returned as:

<data>
  <var>
    <name>c6512.rtc_min</name>
    <value>15</value>
    <description>Minutes of internal real-time clock (0..59).</description>
  </var>
  <var>
    <name>c6512.rtc_sec</name>
    <value>43</value>
    <description>Seconds of internal real-time clock (0..59).</description>
  </var>
</data>

Request string may contain multiple variables and multiple controllers:

  http://localhost/scgi/?c6511.cybro_qx00=1&c6512.cybro_qx00=1

Server first perform writes, then reads. Result is actual value obtained by
reading, even for variables just written. At least one scan of PLC program is
executed in between. If reading fails or plc is stopped, return value is '?'.
Typical access time in local network is 20-50ms.


System variables

Variables provided by server to read the status:

- sys.http_port_status, "active" or no response
- sys.http_request_count, total number of requests
- sys.server_uptime, returned as "dd days, hh:mm:ss"
- sys.server_version, returned as "major.minor.release"
- sys.nad_list, list of controllers detected with a broadcast command:
  <data>
    <var>
      <name>sys.nad_list</name>
      <value>
        <item>1000</item>
        <item>6512</item>
        <item>9462</item>
      </value>
      <description>List of autodetected NADs.</description>
    </var>
  </data>
- c6512.sys.alc_file, download alc file in text format (for debug purposes)


Download file

Server can also be used to download a file, for example app configuration.
File must be located in the same directory as server. URL to acces the file:

  http://localhost/default.zip

File may also be located in any directory below, for example:

  http://localhost/data/default.zip


HTTP port

CyBroHttpServer by default use TCP port 80 for requests. Port must not be used
by another application, and must not be blocked by firewall. Skype use port 80
as alternate connection. To release the port, open Options/Advanced/Connection,
uncheck "alternate port", and restart.

HTTP server can be configured to use any other TCP port. For example, when 8080
is configured, use URL:

  http://localhost:8080/scgi/?c6512.rtc_sec
