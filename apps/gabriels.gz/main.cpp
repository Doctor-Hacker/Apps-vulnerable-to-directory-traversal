#include <stdio.h>
#include <winsock.h>
#include <string.h>
#include <direct.h>
#include <io.h>
#define systemname "WINDOWS"
#define maxcon 20
#define accounts 10
#define bufsize 1000

typedef unsigned int u4;
void die(char * msg);
void clearset(u4 * comsocket, struct sockaddr_in * remote, int * con_num);
int processrequest(int s, struct sockaddr_in * remote, char * buf, int index);
int gfl(char * filename);
void loadconf();
int strhas(char* str, char letter);
//** Global vars **
	char progloc[256];
	char logins[accounts][50];
	char passwords[accounts][50];
	char homes[accounts][50];
	int port;
  struct PERMISSIONS {
    char pread;
    char pwrite;
    char pdelete;
  }permissions[accounts];
	struct PASVDATA {
		char pasvactive;
		int sockfd;
		unsigned short port;
		int lognum;
    long offset;
	};
	char currentdir[maxcon][256];
	int pasvdatanum;
	struct PASVDATA pasvdata[maxcon];
//
int main()
{
	WSADATA wsaData;
	int sockfd;
	u4 comsocket[maxcon];
	int con_num;
	int i;
  char * welcomemsg=
"220- *****************************\r\n     **        Welcome on       **\r\n     *     Gabriel's FTP Server  *\r\n     **      07/2007 Release    **\r\n220  *****************************\r\n";
	int numbytes;
	int addr_len=sizeof(struct sockaddr);
	char * buffer = (char *) malloc(bufsize);
	struct sockaddr_in local;
	struct sockaddr_in remote[maxcon];
	fd_set readfds, tmpfds;
	_getcwd(progloc, 256);
	pasvdatanum=0;
	memset(pasvdata, 0, maxcon * sizeof(PASVDATA));
	memset(logins, 0, 50 * accounts);
	memset(passwords, 0, 50 * accounts);
	memset(homes, 0, 50 * accounts);
	memset(currentdir, 0, maxcon * 256);
	memset(permissions, 0, accounts* sizeof(permissions));
	port=21;
  loadconf();
	/*strcpy(logins[0],"gab");
	strcpy(passwords[0],"aze");
	strcpy(homes[0], "C:\\USB");*/
	if(WSAStartup(MAKEWORD(1,1), &wsaData)==-1) {
		die("wsastartup()");
	}
	local.sin_port=htons(port);
	local.sin_family=PF_INET;
	local.sin_addr.s_addr=INADDR_ANY;
	FD_ZERO(&readfds);
	FD_ZERO(&tmpfds);
	if((sockfd=socket(AF_INET, SOCK_STREAM, 0))==-1) {
		die("socket()");
	}
	if(bind(sockfd, (struct sockaddr *)&local, addr_len)==-1) {
		die("bind();");
	}
	if(listen(sockfd, maxcon)==-1)
		die("listen()");
	con_num=0;
	FD_SET(sockfd, &readfds);
	for(;;) {
		tmpfds=readfds;
		select(0, &tmpfds, 0, 0, 0);
		if(FD_ISSET(sockfd, &tmpfds)) {
			if((comsocket[con_num]=accept(sockfd, (struct sockaddr*)&remote[con_num], &addr_len))==-1) {
				printf("Error on accept()\nContinuing...\n");
				continue;
			}
			else {
				printf("Got connection from %s\n", inet_ntoa(remote[con_num].sin_addr));
				send(comsocket[con_num], welcomemsg, strlen(welcomemsg), 0);
				FD_SET(comsocket[con_num], &readfds);
				con_num++;
			}
		}
		for(i=0;i<con_num;i++) {
			if(FD_ISSET(comsocket[i], &tmpfds)) {
				numbytes=recv(comsocket[i], buffer, bufsize, 0);
				if(numbytes==0 || numbytes==-1) {
					printf("Client %s disconnected\n", inet_ntoa(remote[i].sin_addr));
					FD_CLR(comsocket[i], &readfds);
					closesocket(comsocket[i]);
					comsocket[i]=0;
					memset((char *)&remote[i], 0, sizeof(remote[i]));
					clearset(comsocket, remote, &con_num);
				}
				else {
					buffer[numbytes]=0;
					if(processrequest(comsocket[i], &remote[i], buffer, i)==-1) {
						printf("Client %s disconnected\r\n", inet_ntoa(remote[i].sin_addr));
						closesocket(comsocket[i]);
						comsocket[i]=0;
						memset((char *)&remote[i], 0, sizeof(remote[i]));
						clearset(comsocket, remote, &con_num);
					}
				}
			}
		}

	}
	return 0;
}

void die(char * msg) {
printf("Error : %s\n", msg);
exit(1);
}

void clearset(u4 * comsocket, struct sockaddr_in * remote, int * con_num) {
	u4 * tmp=(u4 *) malloc(*con_num * sizeof(int));
	struct sockaddr_in * tmpaddr=(struct sockaddr_in *) malloc(*con_num * sizeof(struct sockaddr_in));
	int offset=0, i;
	struct PASVDATA * tmppasv=(struct PASVDATA *) malloc(*con_num * sizeof(struct PASVDATA));
	char tmpcwd[maxcon][256];
	for(i=0;i<*con_num;i++) {
		tmp[i]=comsocket[i];
		tmpaddr[i]=remote[i];
		tmppasv[i]=pasvdata[i];
		strcpy(tmpcwd[i], currentdir[i]);
	}
	memset(comsocket, 0, maxcon * 4);
	memset(remote, 0, maxcon * sizeof(struct sockaddr_in));
	for(i=0;i<*con_num;i++) {
		if(tmp[i]!=0) {
			comsocket[offset]=tmp[i];
			remote[offset]=tmpaddr[i];
			pasvdata[offset]=tmppasv[i];
			strcpy(currentdir[offset], tmpcwd[offset]);
			offset++;
		}
	}
	*con_num=offset;
}

int processrequest(int s, struct sockaddr_in * remote, char * buf, int index) {
	int i;
	int dig1, dig2;
	int toknum;
	int addr_len=sizeof(struct sockaddr_in);
	struct sockaddr_in local, pasvremote;
	struct timeval tv;
	tv.tv_sec=3, tv.tv_usec=0;
	local.sin_family=PF_INET;
	local.sin_addr.s_addr=INADDR_ANY;
	int sockfd;
	char syscom[400];
	fd_set readfds;
		char optval='1';
	char * tokens[100];
	char * tmp;
	const int bufsz=10000;
	FILE * f;
	char tmpip[100];
	char newcwd[256];
	int numbytes;
	int portcom[6];
	char line[200];
	char * b;
  int sw;
  int isnewrest=0;
	int fs;
	char * cmd;
	char buf2[256], buf3[256];
	char * sbuf=(char *)malloc(bufsz);
	for(i=0;i<strlen(buf);i++) {
		if(buf[i]=='\r' || buf[i]=='\n')
			buf[i]=0;
	}
	tmp=(char *)malloc(strlen(buf));	
	strcpy(tmp, buf);
	toknum=0;
	b=strtok(tmp, " ");
	tokens[toknum]=(char *) malloc(strlen(b));
	strcpy(tokens[toknum], b);
	toknum++;
	cmd=tokens[0];
	while(b=strtok(0, " ")) {
		tokens[toknum]=(char *) malloc(strlen(b));
		strcpy(tokens[toknum], b);
		toknum++;
	}
  if(_chdir(currentdir[index])==-1) {
		strcpy(currentdir[index], homes[pasvdata[index].lognum]);
    if(_chdir(currentdir[index])==-1) {
      _getcwd(currentdir[index], 256);
    }
  }
	// debug:
	printf("%s requested: \"%s\"\n", inet_ntoa(remote->sin_addr), buf);
	//
	//-----------------------
	if(strcmp(cmd, "USER")==0) {
		printf("%s sent login \"%s\"\n", inet_ntoa(remote->sin_addr), tokens[1]);
		for(i=0;i<accounts;i++) {
			if(strcmp(tokens[1], logins[i])==0) {
				// login correct
        if(strcmp(tokens[1], "anonymous")==0) {
				  sprintf(sbuf, "331 Anonymous login OK send e-mail address for password.\r\n", tokens[1]);
				  send(s, sbuf, strlen(sbuf), 0);
        }
        else {
				  sprintf(sbuf, "331 Password required for %s\r\n", tokens[1]);
				  send(s, sbuf, strlen(sbuf), 0);
        }
				pasvdata[index].lognum=i;
				return 0;
			}
		}
		// incorrect login
		sprintf(sbuf, "530 Login incorrect. Bye.\r\n");
		send(s, sbuf, strlen(sbuf), 0);
		return -1;
	}
	else if(strcmp(cmd, "PASS")==0) {
		printf("%s sent password \"%s\"\n", inet_ntoa(remote->sin_addr), tokens[1]);
		if(strcmp(tokens[1], passwords[pasvdata[index].lognum])==0 
      || strcmp(logins[pasvdata[index].lognum], "anonymous")==0 ) {
			// password correct
			sprintf(sbuf, "230 User %s logged in\r\n", logins[pasvdata[index].lognum]);
			send(s, sbuf, strlen(sbuf), 0);
			return 0;
		}
		// incorrect password
		sprintf(sbuf, "530 Login or Password incorrect. Bye!\r\n");
		send(s, sbuf, strlen(sbuf), 0);
		return -1;
	}
	else if(strcmp(cmd, "LIST")==0  ) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
		memset(sbuf,0,10000);
		sprintf(sbuf, "150 Opening Binary mode connection for file list.\r\n");
		send(s, sbuf, strlen(sbuf), 0);
		sprintf(syscom, "dir /b /ad > \"%s\\list.tmp\"", progloc);
		system(syscom);
		sprintf(buf2, "%s\\list.tmp", progloc);
		if((f=fopen(buf2, "r"))==0) {
			sprintf(sbuf, "500 Internal Error\r\n");
			send(pasvdata[index].sockfd, sbuf, strlen(sbuf), 0);			
			return 0;
		}
		while(fgets(line, 200, f)) {
			if(strlen(line)<2) // empty line
				continue;
			line[strlen(line)-1]=0;
			if(strcmp(line, ".")==0 ||strcmp(line, "..")==0)
				sprintf(sbuf, "drwxr-xr-x 2 admin admin 0 Jan 1 2000 %s\r\n", line);
			else
				sprintf(sbuf, "drwx--xr-x 2 admin admin 0 Jan 1 2000 %s\r\n", line);
			send(pasvdata[index].sockfd, sbuf, strlen(sbuf), 0);
		}
		fclose(f);
		sprintf(syscom, "dir /b /a-d > \"%s\\list.tmp\"", progloc);
		system(syscom);
		if((f=fopen(buf2, "r"))==0) {
			sprintf(sbuf, "500 Internal Error\r\n");
			send(pasvdata[index].sockfd, sbuf, strlen(sbuf), 0);			
			return 0;
		}
		while(fgets(line, 200, f)) {
			if(strlen(line)<2) // empty line
				continue;
			line[strlen(line)-1]=0;
			if((fs=gfl(line))==-1)
				continue;
			sprintf(sbuf, "-rw-r--r-- 1 admin admin %d Jan 1 2000 %s\r\n", fs, line);
			send(pasvdata[index].sockfd, sbuf, strlen(sbuf), 0);
		}
		fclose(f);
		closesocket(pasvdata[index].sockfd);
		pasvdata[index].pasvactive=0;
		sprintf(sbuf, "226 Transfert Complete.\r\n");
		send(s, sbuf, strlen(sbuf), 0);
	}
	else if(strcmp(cmd, "NLST")==0 ) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
		memset(sbuf,0,10000);
		sprintf(sbuf, "150 Opening Binary mode connection for file list.\r\n");
		send(s, sbuf, strlen(sbuf), 0);
		system("dir /b /ad > list.tmp");
		f=fopen("list.tmp", "r");
		while(fgets(line, 200, f)) {
			if(strlen(line)<2) // empty line
				continue;
			line[strlen(line)-1]=0;
				sprintf(sbuf, "%s\r\n", line);
			send(pasvdata[index].sockfd, sbuf, strlen(sbuf), 0);
		}
		fclose(f);
		system("dir /b /a-d > list.tmp");
		f=fopen("list.tmp", "r");
		while(fgets(line, 200, f)) {
			if(strlen(line)<2) // empty line
				continue;
			line[strlen(line)-1]=0;
				sprintf(sbuf, "%s\r\n", line);
			send(pasvdata[index].sockfd, sbuf, strlen(sbuf), 0);
		}
		fclose(f);
		closesocket(pasvdata[index].sockfd);
		pasvdata[index].pasvactive=0;
		sprintf(sbuf, "226 Transfert Complete.\r\n");
		send(s, sbuf, strlen(sbuf), 0);
	}
	else if(strcmp(cmd, "PWD")==0 ||strcmp(cmd, "XPWD")==0) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
		_getcwd(buf2, 256);
		// debug
		//strcpy(buf2, "/");
		sprintf(sbuf, "257 \"%s\" is current directory.\r\n", buf2);
		send(s, sbuf, strlen(sbuf), 0);			
	}
	else if(strcmp(cmd, "TYPE")==0) {
		// Ignore it 
		if(strcmp(tokens[1], "I")==0) {
			sprintf(sbuf, "200 Type set to binary.\r\n");
			send(s, sbuf, strlen(sbuf), 0);	
		}
		else {
			sprintf(sbuf, "200 Type set to ascii.\r\n");
			send(s, sbuf, strlen(sbuf), 0);	
		}		
	}
	else if(strcmp(cmd, "PASV")==0) {
		pasvdata[index].port=10000+index*2;
		pasvdata[index].pasvactive=1;
		local.sin_port=htons(pasvdata[index].port);
		local.sin_addr.s_addr=INADDR_ANY;
		dig1=(int)(pasvdata[index].port/256);
		dig2=pasvdata[index].port % 256;
		FD_ZERO(&readfds);
		if((sockfd=socket(PF_INET, SOCK_STREAM, 0))==-1) {
			sprintf(sbuf, "425 Can't open data connection.\r\n");
			send(s, sbuf, strlen(sbuf), 0);	
			goto err1;
		}
		if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval))==-1) {
			sprintf(sbuf, "425 Can't open data connection.\r\n");
			send(s, sbuf, strlen(sbuf), 0);	
			goto err1;
		}
		if(bind(sockfd, (struct sockaddr *)&local, addr_len)==-1) {
			sprintf(sbuf, "425 Can't open data connection.\r\n");
			send(s, sbuf, strlen(sbuf), 0);		
			goto err1;
		}
		if(listen(sockfd, 1)==-1) {
			sprintf(sbuf, "425 Can't open data connection.\r\n");
			send(s, sbuf, strlen(sbuf), 0);		
			goto err1;
		}
		printf("Listening %d seconds @ port %d\n", tv.tv_sec, pasvdata[index].port);
		sprintf(sbuf, "227 Entering passive mode (%d,%d,%d,%d,%d,%d)\r\n", 127, 0, 0, 1, dig1, dig2);
		send(s, sbuf, strlen(sbuf), 0);
		FD_SET(sockfd, &readfds);
		select(0, &readfds, 0, 0, &tv);
		if(FD_ISSET(sockfd, &readfds)) {
			if((pasvdata[index].sockfd=accept(sockfd, (struct sockaddr*)&pasvremote, &addr_len))==-1) {
				sprintf(sbuf, "425 Can't open data connection.\r\n");
				send(s, sbuf, strlen(sbuf), 0);
				goto err1;
			}
			else {
				printf("Got Data(PASV) connection from %s\n", inet_ntoa(pasvremote.sin_addr));
				pasvdata[index].pasvactive=1;
				closesocket(sockfd);
			}
		}
		else {
err1:
			closesocket(sockfd);
			pasvdata[index].pasvactive=0;
			return 0;
		}
	}
	else if (strcmp(cmd, "RETR")==0) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
		strcpy(buf3, buf+5);
		sprintf(buf2, "%s\\%s", currentdir[index], buf3);
		if((fs=gfl(buf2))==-1) {
      if ((fs=gfl(buf3))==-1){
			  sprintf(sbuf, "550 \"%s\" : not a regular file\r\n", buf3);
			  send(s, sbuf, strlen(sbuf), 0);	
        pasvdata[index].offset=0;
        return 0;
      }	
		}
    if((f=fopen(buf2, "rb"))==0) {
      if((f=fopen(buf3, "rb"))==0) {
        return 0;
      }
    }
    if(pasvdata[index].offset>0 && pasvdata[index].offset < fs) {
      fseek(f, pasvdata[index].offset, SEEK_SET);
      sprintf(sbuf, "150 Opening binary mode data connection for partial \"%s\" (%d/%d bytes).\r\n", 
        buf3, fs-pasvdata[index].offset, fs);
    }
    else {
		  sprintf(sbuf, "150 Opening binary mode data connection for \"%s\" (%d bytes).\r\n", buf3, fs);
    }
		send(s, sbuf, strlen(sbuf), 0);
		while((numbytes=fread(sbuf, 1, bufsz,  f))>0) {
			send(pasvdata[index].sockfd, sbuf, numbytes, 0);
		}
		sprintf(sbuf, "226 Finished.\r\n");
		send(s, sbuf, strlen(sbuf), 0);
		closesocket(pasvdata[index].sockfd);
	}
	else if (strcmp(cmd, "STOR")==0) {
    if(!permissions[pasvdata[index].lognum].pwrite) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
		strcpy(buf3, buf+5);
    if(!(f=fopen(buf3, "wb"))) {
		sprintf(sbuf, "550 Cannot open \"%s\" for writing.\r\n", buf3);
		send(s, sbuf, strlen(sbuf), 0);		
		return 0;
	}
    sprintf(sbuf, "150 Opening binary mode data connection for \"%s\".\r\n", buf3);
		send(s, sbuf, strlen(sbuf), 0);
    FD_ZERO(&readfds);
    FD_SET(pasvdata[index].sockfd, &readfds);
    printf("Waiting %d seconds for data...\n", tv.tv_sec);
    sw=1;
    while(select(0, &readfds, 0, 0, &tv)>0 ) {
      sw==1?printf("Got data on data connection.\n"),sw=0:0;
      if((numbytes=recv(pasvdata[index].sockfd, sbuf, bufsz, 0))>0)
        fwrite(sbuf, 1, numbytes, f);
      else if(numbytes==0){
        fclose(f);
        closesocket(pasvdata[index].sockfd);
        sprintf(sbuf, "226 Finished.\r\n");
        send(s, sbuf, strlen(sbuf), 0);
        break;
      }
      else if(numbytes==-1){
        fclose(f);
        closesocket(pasvdata[index].sockfd);
        return -1;
      }
		}
		closesocket(pasvdata[index].sockfd);
	}
	else if(strcmp(cmd, "SIZE")==0) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
		strcpy(buf3, buf+5);
		sprintf(buf2, "%s\\%s", currentdir[index], buf3);
		if((fs=gfl(buf2))==-1) {
      if ((fs=gfl(buf3))==-1){
			  sprintf(sbuf, "550 \"%s\" : not a regular file\r\n", buf3);
			  send(s, sbuf, strlen(sbuf), 0);	        
      }	
		}
    else {
			sprintf(sbuf, "213 %d\r\n", fs);
			send(s, sbuf, strlen(sbuf), 0);		
		}
	}
	else if(strcmp(cmd, "MDTM")==0){
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
			sprintf(sbuf, "550 \"/\" : not a regular file\r\n");
			send(s, sbuf, strlen(sbuf), 0);			
	}
	else if(strcmp(cmd, "SYST")==0) {
			sprintf(sbuf, "215 %s\r\n", systemname);
			send(s, sbuf, strlen(sbuf), 0);		
	}
	else if(strcmp(cmd, "CWD")==0) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
    _getcwd(currentdir[index],256);
		strcpy(buf2, buf+4);
		sprintf(newcwd, "%s\\%s", currentdir[index], buf2);
		if(_chdir(newcwd)==-1) {
			//try with home prefix
			sprintf(newcwd, "%s\\%s", homes[pasvdata[index].lognum], buf2);
			if(_chdir(newcwd)==-1) {
				strcpy(newcwd, buf2);
				if(_chdir(newcwd)==-1) {
					sprintf(sbuf, "550 Cannot find : \"%s\".\r\n", newcwd);
					send(s, sbuf, strlen(sbuf), 0);	
					return 0;
				}
			}
		}
		sprintf(sbuf, "250 Changed to directory \"%s\"\r\n", newcwd);
		send(s, sbuf, strlen(sbuf), 0);	
		strcpy(currentdir[index], newcwd);
		printf("Changed to directory %s", newcwd);
	}
	else if(strcmp(cmd, "CDUP")==0) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
    _getcwd(currentdir[index], 256);
		strcpy(buf2,"..");
		sprintf(newcwd, "%s\\%s", currentdir[index], buf2);
		if(_chdir(newcwd)==-1) {
			//try with home prefix
			sprintf(newcwd, "%s\\%s", homes[pasvdata[index].lognum], buf2);
			if(_chdir(newcwd)==-1) {
				strcpy(newcwd, buf2);
				if(_chdir(newcwd)==-1) {
					sprintf(sbuf, "550 Cannot find : \"%s\".\r\n", newcwd);
					send(s, sbuf, strlen(sbuf), 0);	
					return 0;
				}
			}
		}
		sprintf(sbuf, "250 Changed to directory \"%s\"\r\n", newcwd);
		send(s, sbuf, strlen(sbuf), 0);	
		strcpy(currentdir[index], newcwd);
		printf("Changed to directory %s", newcwd);
	}
	else if(strcmp(cmd, "PORT")==0) {
		FD_ZERO(&readfds);
		if((pasvdata[index].sockfd=socket(AF_INET, SOCK_STREAM, 0))==-1) {
			sprintf(sbuf, "425 Can't open data connection.\r\n");
			send(s, sbuf, strlen(sbuf), 0);	
			goto err1;
		}
		i=0;
		portcom[i++]=atoi(strtok(tokens[1], ".,;()"));
		for(;i<6;i++) 
			portcom[i]=atoi(strtok(0, ".,;()"));
		sprintf(tmpip, "%d.%d.%d.%d", portcom[0], portcom[1], portcom[2], portcom[3]);
		pasvremote.sin_addr.s_addr=inet_addr(tmpip);
		pasvremote.sin_port=htons(portcom[4] * 256 + portcom[5]);
		pasvremote.sin_family=PF_INET;
		if(connect(pasvdata[index].sockfd, (struct sockaddr *)&pasvremote, addr_len)==-1) {
      // is it only local address?try using gloal ip addr
        pasvremote.sin_addr=remote[index].sin_addr;
        if(connect(pasvdata[index].sockfd, (struct sockaddr *)&pasvremote, addr_len)==-1) {
				  sprintf(sbuf, "425 Can't open data connection.\r\n");
				  send(s, sbuf, strlen(sbuf), 0);
				  closesocket(pasvdata[index].sockfd);
				  memset(&pasvdata[index], 0, sizeof(struct PASVDATA));
				  return 0;
        }
		}
		pasvdata[index].pasvactive=1;
		pasvdata[index].port=portcom[4] * 256 + portcom[5];
		printf("Connected to Data(PORT) %s @ %d\n", tmpip, portcom[4] * 256 + portcom[5]);
		sprintf(sbuf, "200 Port Command Successful.\r\n");
		send(s, sbuf, strlen(sbuf), 0);			
	}
  else if(strcmp(cmd, "REST")==0) {
    if(!permissions[pasvdata[index].lognum].pread) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
    if(atoi(tokens[1])>=0) {
      pasvdata[index].offset=atoi(tokens[1]);
      sprintf(sbuf, "350 Send RETR or STOR to start transfert.\r\n");
		  send(s, sbuf, strlen(sbuf), 0);	
      isnewrest=1;
    }
  }
  else if(strcmp(cmd, "MKD")==0) {
    if(!permissions[pasvdata[index].lognum].pwrite) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
    strcpy(buf2, buf+4);
    if(_mkdir(buf2)==-1) {
      sprintf(sbuf, "550 File \"%s\" exists.\r\n", buf2);
		  send(s, sbuf, strlen(sbuf), 0);	
    }
    else {
      sprintf(sbuf, "257 directory \"%s\" successfully created.\r\n", buf2);
		  send(s, sbuf, strlen(sbuf), 0);	     
    }
  }
  else if(strcmp(cmd, "DELE")==0) {
    if(!permissions[pasvdata[index].lognum].pdelete) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
    strcpy(buf2, buf+5);
    if(remove(buf2)==0) 
      sprintf(sbuf, "250 Successfully deleted file \"%s\".\r\n", buf2);
    else 
      sprintf(sbuf, "550 Not such file or directory.\r\n");
    send(s, sbuf, strlen(sbuf), 0);	
  }
  else if(strcmp(cmd, "RMD")==0) {
    if(!permissions[pasvdata[index].lognum].pdelete) {
      sprintf(sbuf, "550 Permission denied.\r\n");
      send(s, sbuf, strlen(sbuf), 0);
      return 0;
    }
    strcpy(buf2, buf+4);
    if(_rmdir(buf2)==-1) {
      sprintf(sbuf, "550 Directory \"%s\" doesn't exist.\r\n", buf2);
		  send(s, sbuf, strlen(sbuf), 0);	
    }
    else {
      sprintf(sbuf, "257 directory \"%s\" successfully deleted.\r\n", buf2);
		  send(s, sbuf, strlen(sbuf), 0);	     
    }
  }
	else if(strcmp(cmd, "QUIT")==0) {
		sprintf(sbuf, "221 Bye!\r\n");
		send(s, sbuf, strlen(sbuf), 0);	
		return -1;
	}
	else {
		sprintf(sbuf, "502 Not Implemented.\r\n");
		send(s, sbuf, strlen(sbuf), 0);		
	}
	return 0;
}

int gfl(char * filename)
{
	int pos;
	int end;
	FILE * f;
	if(!(f=fopen(filename, "rb")))
		return -1;
	pos = ftell (f);
	fseek (f, 0, SEEK_END);
	end = ftell (f);
	fseek (f, pos, SEEK_SET);
	fclose(f);
	return end;
}

void loadconf() {
  FILE * f;
  char line[500];
  char * tokens[20];
  char * b;
  int toknum;
  int i;
  int numusers=0;
  if((f=fopen("ftpd.conf", "rt"))==0) {
    printf("Cannot find configuration file ftpd.conf. Using default settings\n");
    strcpy(logins[0],"anonymous");
    strcpy(passwords[0],"anonymous");
    strcpy(homes[0], ".");
    return ;
  }
  while(fgets(line, 500, f)) {
    if(*line=='#')
      continue;
	  for(i=0;i<strlen(line);i++) {
		  if(line[i]=='\r' || line[i]=='\n')
			  line[i]=0;
	  }
	  toknum=0;
	  b=strtok(line, " ");
	  tokens[toknum]=(char *) malloc(strlen(b));
	  strcpy(tokens[toknum], b);
	  toknum++;
	  while(b=strtok(0, " ")) {
		  tokens[toknum]=(char *) malloc(strlen(b));
		  strcpy(tokens[toknum], b);
		  toknum++;
	  }
    if(strcmp(tokens[0], "user")==0) {
      strcpy(logins[numusers],tokens[1]);
      strcpy(passwords[numusers],tokens[2]);
      strcpy(homes[numusers],tokens[3]);
      if(strhas(tokens[4], 'r') || strhas(tokens[4], 'R')) {
        permissions[numusers].pread=1;
      }
      if(strhas(tokens[4], 'w') || strhas(tokens[4], 'W')) {
        permissions[numusers].pwrite=1;
      }
      if(strhas(tokens[4], 'd') || strhas(tokens[4], 'D')) {
        permissions[numusers].pdelete=1;
      }
      printf("Added user %d login:\"%s\" pass:\"%s\" home:\"%s\" permissions:\"%s%s%s\"\n",
        numusers, logins[numusers], passwords[numusers], homes[numusers], 
        permissions[numusers].pread==1?"r":"-", permissions[numusers].pwrite==1?"w":"-",
        permissions[numusers].pdelete==1?"d":"-");
      numusers++;
    }
		else if(strcmp(tokens[0], "port")==0) {
			if((port=atoi(tokens[1]))==0)
				port=21;
			printf("Listen port set to %d\n", port);
		}
		else
			continue;
  }
}

int strhas(char* str, char letter) {
  while(*str) {
    if(*str==letter)
      return 1;
    str++;
  }
  return 0;
}